package br.com.dbccompany.bancodigital;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BancodigitalApplicationTests {

	@Test
	void contextLoads() {
	}

}
