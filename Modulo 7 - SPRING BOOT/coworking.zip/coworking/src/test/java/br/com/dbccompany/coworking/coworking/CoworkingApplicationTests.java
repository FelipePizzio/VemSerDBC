package br.com.dbccompany.coworking.coworking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoworkingApplicationTests {

	@Test
	void contextLoads() {
	}

}
